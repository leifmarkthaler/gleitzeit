"""
Gleitzeit Test Suite

Test utilities and configuration for the Gleitzeit cluster library.
"""