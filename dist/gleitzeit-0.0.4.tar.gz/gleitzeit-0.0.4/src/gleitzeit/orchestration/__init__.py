"""
Orchestration components for multi-instance support
"""
