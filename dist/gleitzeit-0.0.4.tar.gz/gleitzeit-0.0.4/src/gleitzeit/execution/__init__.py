"""
Execution environments for Python code
"""
